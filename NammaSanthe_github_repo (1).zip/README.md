# NammaSanthe APK Extract

This repository package was generated from the provided APK file.

## Included
- AndroidManifest.xml
- classes.dex / classes2.dex
- assets/
- res/
- META-INF/
- resources.arsc

## Notes
- Native libraries and large binary assets were excluded to keep the archive under 20 MB.
- The `.dex` files contain the compiled Android application code.
- You can decompile the `.dex` files using tools such as JADX or APKTool locally.

## Suggested GitHub Structure
```bash
git init
git add .
git commit -m "Initial APK extraction"
```